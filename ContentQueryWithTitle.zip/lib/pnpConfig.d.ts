import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export declare const getSP: (context?: WebPartContext) => SPFI;
//# sourceMappingURL=pnpConfig.d.ts.map
/* tslint:disable */
require("./ContentQuery.module.css");
const styles = {
  contentQuery: 'contentQuery_6f28fd2b',
  teams: 'teams_6f28fd2b',
  welcome: 'welcome_6f28fd2b',
  welcomeImage: 'welcomeImage_6f28fd2b',
  links: 'links_6f28fd2b'
};

export default styles;
/* tslint:enable */